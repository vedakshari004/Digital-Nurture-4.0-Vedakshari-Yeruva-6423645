package org.example;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.example.Main;

public class MainTest {

    @Test
    void testSampleAdd() {
        Main main = new Main();
        int result = main.sampleAdd(2, 3);

        // 🖨️ Print result to output
        System.out.println("Result from sampleAdd(2, 3): " + result);

        assertEquals(5, result, "2 + 3 should equal 5");
    }
}
