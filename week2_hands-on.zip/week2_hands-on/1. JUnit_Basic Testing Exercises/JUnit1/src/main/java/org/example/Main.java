package org.example;

public class Main {
    public int sampleAdd(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        System.out.println("Hello from Main!");
    }
}
