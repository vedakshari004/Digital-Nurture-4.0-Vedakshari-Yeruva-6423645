package org.example;

public class Main {
    public int sampleAdd(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        System.out.println("Hello from Main!");
    }
    public int add(int a, int b) {
        return a + b;
    }

    public boolean isEven(int number) {
        return number % 2 == 0;
    }

    public String greet(String name) {
        return "Hello, " + name;
    }

    public Object getNull() {
        return null;
    }

}
