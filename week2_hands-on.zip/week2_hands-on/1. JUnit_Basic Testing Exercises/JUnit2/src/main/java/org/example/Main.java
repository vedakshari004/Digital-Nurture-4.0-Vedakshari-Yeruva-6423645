package org.example;

public class Main {

    // Adds two integers
    public int add(int a, int b) {
        return a + b;
    }

    // Checks if a number is even
    public boolean isEven(int number) {
        return number % 2 == 0;
    }

    // Returns a greeting message
    public String greet(String name) {
        return "Hello, " + name;
    }

    // Returns null (to test assertNull)
    public Object getNull() {
        return null;
    }

    public static void main(String[] args) {
        System.out.println("Main class running.");
    }
}
