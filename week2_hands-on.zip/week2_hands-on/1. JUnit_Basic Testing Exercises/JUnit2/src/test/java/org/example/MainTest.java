package org.example;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MainTest {

    Main main = new Main();

    @Test
    void testAdd() {
        int result = main.add(3, 4);
        System.out.println("Add Result: " + result);
        assertEquals(7, result, "3 + 4 should equal 7");
    }

    @Test
    void testIsEvenTrue() {
        assertTrue(main.isEven(10), "10 should be even");
    }

    @Test
    void testIsEvenFalse() {
        assertFalse(main.isEven(7), "7 should not be even");
    }

    @Test
    void testGreeting() {
        String message = main.greet("Alice");
        System.out.println("Greeting: " + message);
        assertEquals("Hello, Alice", message);
    }

    @Test
    void testNotNullGreeting() {
        assertNotNull(main.greet("Bob"), "Greeting should not be null");
    }

    @Test
    void testNullObject() {
        assertNull(main.getNull(), "Expected null from getNull()");
    }
}
