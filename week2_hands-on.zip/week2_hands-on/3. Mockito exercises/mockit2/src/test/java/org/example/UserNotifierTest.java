// UserNotifierTest.java
package org.example;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

public class UserNotifierTest {

    @Test
    public void testNotifyUser_WhenImportant_ShouldSendMessage() {
        MessageService mockService = mock(MessageService.class);
        UserNotifier notifier = new UserNotifier(mockService);
        notifier.notifyUser(true);
        verify(mockService).sendMessage("Important Notification!");
    }

    @Test
    public void testNotifyUser_WhenNotImportant_ShouldNotSendMessage() {
        MessageService mockService = mock(MessageService.class);
        UserNotifier notifier = new UserNotifier(mockService);
        notifier.notifyUser(false);
        verify(mockService, never()).sendMessage(anyString());
    }
}
