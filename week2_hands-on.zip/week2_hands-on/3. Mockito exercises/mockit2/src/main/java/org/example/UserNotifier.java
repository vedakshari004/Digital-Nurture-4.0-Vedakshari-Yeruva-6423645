package org.example;

public class UserNotifier {
    private final MessageService messageService;

    public UserNotifier(MessageService messageService) {
        this.messageService = messageService;
    }

    public void notifyUser(boolean important) {
        if (important) {
            messageService.sendMessage("Important Notification!");
        }
    }
}
