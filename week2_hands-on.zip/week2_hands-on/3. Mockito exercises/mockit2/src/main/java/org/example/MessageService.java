package org.example;

public interface MessageService {
    void sendMessage(String message);
}
