package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class BusinessLogicTest {

    @Test
    void testFindGreatest() {
        DataService mockDataService = mock(DataService.class);
        when(mockDataService.getData()).thenReturn(new int[]{10, 20, 5});
        BusinessLogic logic = new BusinessLogic(mockDataService);
        int result = logic.findGreatest();
        assertEquals(20, result);
    }
}
