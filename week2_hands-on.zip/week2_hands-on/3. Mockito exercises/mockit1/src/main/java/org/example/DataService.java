package org.example;

public interface DataService {
    int[] getData();
}
