package org.example;

public class BusinessLogic {

    private DataService dataService;

    // Constructor-based injection
    public BusinessLogic(DataService dataService) {
        this.dataService = dataService;
    }

    public int findGreatest() {
        int[] data = dataService.getData();
        int max = Integer.MIN_VALUE;
        for (int value : data) {
            if (value > max) {
                max = value;
            }
        }
        return max;
    }
}

