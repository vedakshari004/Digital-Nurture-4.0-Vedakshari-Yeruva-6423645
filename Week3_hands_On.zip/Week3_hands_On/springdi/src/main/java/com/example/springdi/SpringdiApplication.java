package com.example.springdi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringdiApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringdiApplication.class, args);
	}
}
