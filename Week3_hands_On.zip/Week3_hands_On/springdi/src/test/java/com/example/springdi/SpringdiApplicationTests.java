package com.example.springdi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringdiApplicationTests {

	@Test
	void contextLoads() {
	}

}
